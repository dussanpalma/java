package calculadoraProject;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;

class MarcoCalculadora extends JFrame {

    public MarcoCalculadora() {

        Toolkit mipantalla = Toolkit.getDefaultToolkit();
        Image miIcono = mipantalla.getImage("src/calculadoraProject/calculadora.gif");
        setIconImage(miIcono);

        setTitle("Calculadora");
        setBounds(300, 300, 350, 300);

        LaminaCalculadora milamina = new LaminaCalculadora();

        add(milamina);

        // para poner los botones, del mismo tamaño que lo que llevedentro
        //  pack();

    }

}
    
    
