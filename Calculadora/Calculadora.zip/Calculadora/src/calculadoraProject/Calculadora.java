package calculadoraProject;

import javax.swing.*;

public class Calculadora {

    public static void main(String[] args) {

        MarcoCalculadora mimarco = new MarcoCalculadora();
        mimarco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mimarco.setVisible(true);

    }

}




